package com.example.bankapp_v10;

import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class AgregarTarjeta extends AppCompatActivity {

    EditText no_tarjeta;
    EditText cuenta;
    EditText issure;
    EditText name_card;
    EditText marca;
    EditText estatus;
    EditText saldo;
    EditText tipo_cuenta;

    ImageButton cancelar;
    ImageButton aceptar;

    protected void onCreate(Bundle savedInstaceState) {
        super.onCreate(savedInstaceState);
        setContentView(R.layout.agregar_tarjeta);

        no_tarjeta = (EditText) findViewById(R.id.notarjeta);
        cuenta = (EditText) findViewById(R.id.cuenta);
        issure = (EditText) findViewById(R.id.issure);
        name_card = (EditText) findViewById(R.id.nombretarjeta);
        marca = (EditText) findViewById(R.id.marca);
        estatus = (EditText) findViewById(R.id.estatus);
        saldo = (EditText) findViewById(R.id.saldo);
        tipo_cuenta = (EditText) findViewById(R.id.tipocuenta);

        cancelar = (ImageButton) findViewById(R.id.btncancelar);
        aceptar = (ImageButton) findViewById(R.id.btnaceptar);

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int auxnt = Integer.parseInt(no_tarjeta.getText().toString());
                int auxc = Integer.parseInt(cuenta.getText().toString());
                int auxiss = Integer.parseInt(issure.getText().toString());
                String auxname = name_card.getText().toString();
                String auxm = marca.getText().toString();
                String auxest = estatus.getText().toString();
                int auxs = Integer.parseInt(saldo.getText().toString());
                String auxtp = tipo_cuenta.getText().toString();

                EstructuraAsociarT nuevaTarjeta = new EstructuraAsociarT(auxnt, auxc, auxiss, auxname, auxm, auxest, auxs, auxtp);
                Context context = getApplicationContext();

                Toast toast = Toast.makeText(context, nuevaTarjeta.toJSON(), Toast.LENGTH_SHORT);
                toast.show();

            }
        });

    }
}
