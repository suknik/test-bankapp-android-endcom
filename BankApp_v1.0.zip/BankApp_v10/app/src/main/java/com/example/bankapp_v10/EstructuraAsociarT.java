package com.example.bankapp_v10;

import org.json.JSONException;
import org.json.JSONObject;

public class EstructuraAsociarT {

    private int no_tarjeta;
    private int cuenta;
    private int issure;
    private String name_card;
    private String marca;
    private String status;
    private int saldo;
    private String tipo_cuenta;

    EstructuraAsociarT(int no_tarjeta, int cuenta, int issure, String name_card, String marca, String status, int saldo, String tipo_cuenta){
        this.no_tarjeta = no_tarjeta;
        this.cuenta = cuenta;
        this.issure = issure;
        this.name_card = name_card;
        this.marca = marca;
        this.status = status;
        this.saldo = saldo;
        this.tipo_cuenta = tipo_cuenta;
    }

    public int getNo_tarjeta() {
        return no_tarjeta;
    }

    public void setNo_tarjeta(int no_tarjeta) {
        this.no_tarjeta = no_tarjeta;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public int getIssure() {
        return issure;
    }

    public void setIssure(int issure) {
        this.issure = issure;
    }

    public String getName_card() {
        return name_card;
    }

    public void setName_card(String name_card) {
        this.name_card = name_card;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public String getTipo_cuenta() {
        return tipo_cuenta;
    }

    public void setTipo_cuenta(String tipo_cuenta) {
        this.tipo_cuenta = tipo_cuenta;
    }

    public String toJSON(){
        JSONObject jsonObject = new JSONObject();

        try{
            jsonObject.put("numeroTarjeta", getNo_tarjeta());
            jsonObject.put("cuenta", getCuenta());
            jsonObject.put("issure", getIssure());
            jsonObject.put("nombreTarjeta", name_card);
            jsonObject.put("marca", getMarca());
            jsonObject.put("status", getStatus());
            jsonObject.put("saldo", getSaldo());
            jsonObject.put("tipoCuenta", getTipo_cuenta());

            return jsonObject.toString();
        }catch (JSONException e){
            e.printStackTrace();
            return "";
        }
    }
}
