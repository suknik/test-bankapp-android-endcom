package com.example.bankapp_v10;

public class EstructuraSaldos {

    private String descripcion;
    private int saldo;

    EstructuraSaldos(String descripcion, int monto){

        this.descripcion = descripcion;
        this.saldo = monto;

    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
}
