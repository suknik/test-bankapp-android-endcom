package com.example.bankapp_v10;

public class EstructuraTarjeta {

    private String tarjeta;
    private String nombre;
    private int saldo;
    private String estado;
    private  String tipo;

    public EstructuraTarjeta (String tarjeta, String nombre, int saldo, String estado, String tipo){

        this.tarjeta = tarjeta;
        this.nombre = nombre;
        this.saldo = saldo;
        this.estado = estado;
        this.tipo = tipo;
    }


    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
