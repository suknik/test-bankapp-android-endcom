package com.example.bankapp_v10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView listaNumeros;
    private RecyclerView saldos;
    private RecyclerView tarjetas;
    private RecyclerView movimientos;
    private static final int LISTA_NUMEROS = 100;
    private TextView vincular_card;

    private static ArrayList<EstructuraMovimientos> movimientos_lista = new ArrayList<EstructuraMovimientos>();
    private static ArrayList<EstructuraTarjeta> tarjetas_lista = new ArrayList<>();
    private static ArrayList<EstructuraSaldos> saldos_lista = new ArrayList<>();

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vincular_card = (TextView)findViewById(R.id.agregarTarjeta);
        vincular_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, AgregarTarjeta.class);
                startActivity(intent);
            }
        });



        //***************************************************************************************************************

        //Definición del RecyclerView para los saldos

        EstructuraSaldos s1 = new EstructuraSaldos("Saldo General", 2000);
        EstructuraSaldos s2 = new EstructuraSaldos("ingresos", 8000);
        EstructuraSaldos s3 = new EstructuraSaldos("gastos", 6000);

        saldos_lista.add(s1);
        saldos_lista.add(s2);
        saldos_lista.add(s3);

        saldos = findViewById(R.id.saldos);
        //saldos.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.HORIZONTAL));
        LinearLayoutManager layoutSaldos =new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        saldos.setLayoutManager(layoutSaldos);
        SaldosAdapter adapterSaldos = new SaldosAdapter(saldos_lista);

        saldos.setAdapter(adapterSaldos);

        //*************************************************************************************************************
        //Definición del RecyclerView para los tarjetas

        EstructuraTarjeta t1 = new EstructuraTarjeta("5439240112341234", "Berenice Garcia Lopez", 1500, "activa", "titular");
        EstructuraTarjeta t2 = new EstructuraTarjeta("5439240112341235", "Lilly Silva Martinez", 500, "desactivada", "titular");

        tarjetas_lista.add(t1);
        tarjetas_lista.add(t2);

        tarjetas = findViewById(R.id.tarjetas);
        tarjetas.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        LinearLayoutManager layoutTarjetas = new LinearLayoutManager(this);
        tarjetas.setLayoutManager(layoutTarjetas);
        TarjetasAdapter adapterTarjetas = new TarjetasAdapter(tarjetas_lista);

        tarjetas.setAdapter(adapterTarjetas);

        //************************************************************************************************************
        //Definición del RecyclerView para los movimientos

        EstructuraMovimientos m1 = new EstructuraMovimientos("01/07/2019", "Lorem ipsum dolor sit amet, consectetur adipiscing elit.", "30.00", "abono");
        EstructuraMovimientos m2 = new EstructuraMovimientos("02/07/2019", "Quisque imperdiet massa vel lacus vehicula, a dapibus dolor ullamcorper.", "100.00", "abono");
        EstructuraMovimientos m3 = new EstructuraMovimientos("03/07/2019","Donec posuere ex ut neque auctor varius.","10.00","cargo");

        movimientos_lista.add(m1);
        movimientos_lista.add(m2);
        movimientos_lista.add(m3);

        movimientos = findViewById(R.id.movimientos);
        movimientos.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        LinearLayoutManager layoutMovimientos = new LinearLayoutManager(this);
        movimientos.setLayoutManager(layoutMovimientos);
        MovimientosAdapter adapterMovmientos = new MovimientosAdapter(movimientos_lista);

        movimientos.setAdapter(adapterMovmientos);

        //***********************************************************************************************************

        /*listaNumeros = findViewById(R.id.listanumeros);

        listaNumeros.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        LinearLayoutManager linearLayoutmanager = new LinearLayoutManager(this);
        listaNumeros.setLayoutManager(linearLayoutmanager);

        RecycleAdapter mAdapter = new RecycleAdapter(LISTA_NUMEROS);

        listaNumeros.setAdapter(mAdapter);*/
    }
}