package com.example.bankapp_v10;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MovimientosAdapter extends RecyclerView.Adapter<MovimientosAdapter.MovimientosViewHolder> {

    ArrayList<EstructuraMovimientos> listamovimientos;

    public MovimientosAdapter(ArrayList<EstructuraMovimientos> listamovimientos){
        this.listamovimientos = listamovimientos;
    }


    @NonNull
    @Override
    public MovimientosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context =viewGroup.getContext();
        int layout_mov =R.layout.lista_movimientos_row;
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(layout_mov, viewGroup,false);

        MovimientosViewHolder viewHolder = new MovimientosViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MovimientosAdapter.MovimientosViewHolder movimientosViewHolder, int i) {
        movimientosViewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
            return listamovimientos.size();
    }

    public class MovimientosViewHolder extends RecyclerView.ViewHolder{

        TextView tvDescripcion;
        TextView tvMonto;
        TextView tvFecha;

        public MovimientosViewHolder(@NonNull View itemView) {
            super(itemView);

            tvDescripcion = itemView.findViewById(R.id.descripcion);
            tvMonto = itemView.findViewById(R.id.monto);
            tvFecha = itemView.findViewById(R.id.fecha);

        }

        void bind(int indexLista){

            EstructuraMovimientos movimiento = listamovimientos.get(indexLista);

            tvDescripcion.setText(String.valueOf(movimiento.getDescripcion()));

            if(String.valueOf(movimiento.getTipo()).equals("abono")){
                tvMonto.setTextColor(Color.GREEN);
                tvMonto.setText(String.valueOf(movimiento.getMonto()));
            }else{
                tvMonto.setTextColor(Color.RED);
                tvMonto.setText(String.valueOf(movimiento.getMonto()));
            }

            tvFecha.setText(String.valueOf(movimiento.getFecha()));
        }

    }
}
