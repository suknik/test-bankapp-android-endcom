package com.example.bankapp_v10;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.NumerosViewHolder> {

    private int mNumerosItems;

    public RecycleAdapter(int numeroDeItems){
        mNumerosItems = numeroDeItems;
    }


    @NonNull
    @Override
    public NumerosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context mContext = viewGroup.getContext();
        int layoutIdParaListItem = R.layout.lista_numeros_row;
        LayoutInflater inflater = LayoutInflater.from(mContext);
        boolean attachToParentRapido = false;

        View view = inflater.inflate(layoutIdParaListItem,viewGroup,attachToParentRapido);

        NumerosViewHolder viewHolder = new NumerosViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull NumerosViewHolder numerosViewHolder, int i) {
        numerosViewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return mNumerosItems;
    }

    public class NumerosViewHolder extends RecyclerView.ViewHolder{

        TextView mTvListaNumerosView;

        public NumerosViewHolder(@NonNull View itemView) {
            super(itemView);

            mTvListaNumerosView =itemView.findViewById(R.id.listanumeros);
        }

        void bind(int listaIndex){
            mTvListaNumerosView.setText(String.valueOf(listaIndex));
        }
    }

    public class saldosViewHolder {
    }
}
