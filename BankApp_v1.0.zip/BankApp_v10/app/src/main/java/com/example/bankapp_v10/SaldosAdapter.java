package com.example.bankapp_v10;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class SaldosAdapter extends RecyclerView.Adapter<SaldosAdapter.SaldosViewHolder> {

    ArrayList<EstructuraSaldos> saldos_lista = new ArrayList<>();

    public SaldosAdapter(ArrayList<EstructuraSaldos> saldos_lista){

        this.saldos_lista = saldos_lista;

    }

    @NonNull
    @Override
    public SaldosAdapter.SaldosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context = viewGroup.getContext();
        int layout_saldo = R.layout.lista_saldos;
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(layout_saldo, viewGroup, false);

        SaldosViewHolder viewHolder = new SaldosViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull SaldosAdapter.SaldosViewHolder saldosViewHolder, int i) {
        saldosViewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return saldos_lista.size();
    }

    public class SaldosViewHolder extends RecyclerView.ViewHolder {

        TextView tv_descripcion;
        TextView tv_cantidad;

        public SaldosViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_descripcion = itemView.findViewById(R.id.descripcion);
            tv_cantidad = itemView.findViewById(R.id.cantidad);

        }

        void bind(int indexlista){
            EstructuraSaldos saldo = saldos_lista.get(indexlista);

            Log.i("descripcion",String.valueOf(saldo.getDescripcion()));
            Log.i("saldo",String.valueOf(saldo.getSaldo()));

            tv_descripcion.setText(String.valueOf(saldo.getDescripcion()));

            if (String.valueOf(saldo.getDescripcion()).equals("ingresos")){
                tv_cantidad.setTextColor(Color.GREEN);
                tv_cantidad.setText(String.valueOf(saldo.getSaldo()));
            }
            if(String.valueOf(saldo.getDescripcion()).equals("gastos")){
                tv_cantidad.setTextColor(Color.RED);
                tv_cantidad.setText(String.valueOf(saldo.getSaldo()));
            }else{
                tv_cantidad.setText(String.valueOf(saldo.getSaldo()));
            }
        }
    }
}
