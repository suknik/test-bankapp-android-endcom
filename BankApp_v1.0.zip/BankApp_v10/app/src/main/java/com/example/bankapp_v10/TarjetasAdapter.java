package com.example.bankapp_v10;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TarjetasAdapter extends RecyclerView.Adapter<TarjetasAdapter.TarjetasViewHolder> {

    ArrayList<EstructuraTarjeta> lista_tarjetas;

    public TarjetasAdapter(ArrayList<EstructuraTarjeta> listatarjetas){

        this.lista_tarjetas = listatarjetas;
    }

    @NonNull
    @Override
    public TarjetasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        Context context = viewGroup.getContext();
        int layout_card = R.layout.lista_tarjetas_row;
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(layout_card, viewGroup, false);

        TarjetasViewHolder viewHolder = new TarjetasViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull TarjetasViewHolder tarjetasViewHolder, int i) {
        tarjetasViewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return lista_tarjetas.size();
    }

    public class TarjetasViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_tarjeta;
        TextView tv_notarjeta;
        TextView tv_nombre;
        TextView tv_saldo;
        TextView tv_estado;
        TextView tv_tipo;

        public TarjetasViewHolder(@NonNull View itemView) {
            super(itemView);

            iv_tarjeta = itemView.findViewById(R.id.imgtarjeta);
            tv_estado = itemView.findViewById(R.id.estado);
            tv_saldo = itemView.findViewById(R.id.saldo);
            tv_notarjeta = itemView.findViewById(R.id.notarjeta);
            tv_nombre = itemView.findViewById(R.id.nombre);
            tv_tipo = itemView.findViewById(R.id.tipo);
        }

        void bind(int indexLista){
            EstructuraTarjeta tarjeta = lista_tarjetas.get(indexLista);

            if(String.valueOf(tarjeta.getEstado()).equals("desactivada")){
                iv_tarjeta.setImageResource(R.mipmap.tarjetai);
            }else{
                iv_tarjeta.setImageResource(R.mipmap.tarjetaa);
            }

            tv_estado.setText(String.valueOf(tarjeta.getEstado()));
            tv_saldo.setText("$"+String.valueOf(tarjeta.getSaldo()));
            tv_notarjeta.setText(String.valueOf(tarjeta.getTarjeta()));
            tv_nombre.setText(String.valueOf(tarjeta.getNombre()));
            tv_tipo.setText(String.valueOf(tarjeta.getTipo()));

        }
    }
}
